package com.example.demo.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.example.demo.entity.Transport;

@Component("ts")
public class TransportService {

	@Autowired
	private TransportRepository transRepo;
	
	
	public Transport create(Transport transport)
	{
		return transRepo.save(transport);
	}
	public List<Transport> read()
	{
		return transRepo.findAll();
	}
	
	public Transport read(String transportId)
	{
		return transRepo.findById(transportId).get();
	}
	public Transport update(Transport transport)
	{
		return transRepo.save(transport);
	}
	
	public void delete( String transportId)	
	{
	transRepo.delete(read(transportId));
	}
}
